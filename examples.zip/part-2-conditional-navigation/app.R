# Load packages
library(surveydown)

db <- sd_db_connect(ignore = TRUE)

ui <- sd_ui()

server <- function(input, output, session) {

  # Define any conditional navigation logic here (navigate to page if a condition is true)
  sd_skip_forward(
    input$vehicle_simple == "no" ~ "screenout",
    input$vehicle_complex == "no" &
      input$buy_vehicle == "no" ~ "screenout"
  )

  # Other settings
  sd_server(db = db)
}

# Launch the app
shiny::shinyApp(ui = ui, server = server)
