# Load packages
library(surveydown)

db <- sd_db_connect(ignore = TRUE)

ui <- sd_ui()

server <- function(input, output, session) {

  # Define any conditional display logic here (show a question if a condition is true)
  sd_show_if(

    # Simple conditional display
    input$penguins_simple == "other" ~ "penguins_simple_other",

    # Complex conditional display
    input$penguins_complex == "other" &
      input$show_other == "show" ~ "penguins_complex_other",

    # Conditional display based on a numeric value
    as.numeric(input$car_number) > 1 ~ "ev_ownership",

    # Conditional display based on multiple inputs
    input$fav_fruits %in% c("apple", "banana") ~ "apple_or_banana",
    length(input$fav_fruits) > 3 ~ "fruit_number"
  )

  # Database designation and other settings
  sd_server(db = db)

}

# Launch the app
shiny::shinyApp(ui = ui, server = server)
